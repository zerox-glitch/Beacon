import { ImageIcon, LayoutGrid, Palette, Type } from "lucide-react";
import { useEffect } from "react";
import { Toaster } from "sonner";
import { ContentPanel } from "@/components/studio/content-panel";
import { DesignPanel } from "@/components/studio/design-panel";
import { ImagePanel } from "@/components/studio/image-panel";
import { PresetGallery } from "@/components/studio/preset-gallery";
import { QrStage } from "@/components/studio/qr-stage";
import { ScrollArea } from "@/components/ui/scroll-area";
import { TooltipProvider } from "@/components/ui/tooltip";
import { PRESETS } from "@/lib/qr/presets";
import { useStudio } from "@/lib/store";
import { cn } from "@/lib/utils";

const MOBILE_TABS = [
  { id: "content", label: "Link", icon: Type },
  { id: "image", label: "Image", icon: ImageIcon },
  { id: "presets", label: "Presets", icon: LayoutGrid },
  { id: "design", label: "Design", icon: Palette },
] as const;

export function Studio() {
  const mobileTab = useStudio((s) => s.mobileTab);
  const setMobileTab = useStudio((s) => s.setMobileTab);
  const hydrateHistory = useStudio((s) => s.hydrateHistory);

  useEffect(() => {
    hydrateHistory();
  }, [hydrateHistory]);

  return (
    <TooltipProvider delayDuration={200}>
      <div className="flex min-h-dvh flex-col overflow-x-hidden bg-bg text-fg">
        <header className="flex h-14 shrink-0 items-center justify-between border-b border-border px-4 sm:px-6">
          <div className="flex items-baseline gap-3">
            <h1 className="font-display text-2xl italic leading-none tracking-tight">Beacon</h1>
            <span className="hidden text-xs text-muted sm:inline">Picture QR studio</span>
          </div>
          <p className="text-xs tabular-nums text-subtle">{PRESETS.length} presets</p>
        </header>

        <div className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-[300px_minmax(0,1fr)_340px]">
          <aside className="hidden min-h-0 min-w-0 border-r border-border lg:flex lg:flex-col">
            <div className="border-b border-border px-4 py-3">
              <p className="font-display text-lg italic">Destination</p>
              <p className="text-xs text-muted">What the code opens</p>
            </div>
            <ScrollArea className="min-h-0 flex-1">
              <div className="px-4 py-4">
                <ContentPanel />
              </div>
            </ScrollArea>
          </aside>

          <main className="min-h-0 min-w-0 overflow-x-hidden bg-bg">
            <QrStage />
          </main>

          <aside className="hidden min-h-0 min-w-0 border-l border-border lg:flex lg:flex-col">
            <RightDesktop />
          </aside>
        </div>

        <div className="border-t border-border lg:hidden">
          <div className="max-h-[42dvh] overflow-y-auto px-4 py-4 scrollbar-thin">
            {mobileTab === "content" && <ContentPanel />}
            {mobileTab === "image" && <ImagePanel />}
            {mobileTab === "presets" && <PresetGallery />}
            {mobileTab === "design" && <DesignPanel />}
          </div>
          <nav className="grid grid-cols-4 border-t border-border">
            {MOBILE_TABS.map((t) => {
              const Icon = t.icon;
              const on = mobileTab === t.id;
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setMobileTab(t.id)}
                  className={cn(
                    "flex h-14 flex-col items-center justify-center gap-1 text-[11px] font-medium",
                    on ? "text-fg" : "text-muted",
                  )}
                >
                  <Icon className="size-4" />
                  {t.label}
                </button>
              );
            })}
          </nav>
        </div>
        <Toaster theme="dark" position="bottom-center" richColors={false} />
      </div>
    </TooltipProvider>
  );
}

function RightDesktop() {
  const tab = useStudio((s) => s.mobileTab);
  const setTab = useStudio((s) => s.setMobileTab);
  const desktopTabs = [
    { id: "presets" as const, label: "Presets" },
    { id: "design" as const, label: "Design" },
    { id: "image" as const, label: "Image" },
  ];
  const current = desktopTabs.some((t) => t.id === tab) ? tab : "presets";

  return (
    <>
      <div className="flex gap-1 border-b border-border p-2">
        {desktopTabs.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={cn(
              "h-10 flex-1 rounded-md text-sm font-medium",
              current === t.id ? "bg-surface text-fg" : "text-muted hover:text-fg",
            )}
          >
            {t.label}
          </button>
        ))}
      </div>
      <ScrollArea className="min-h-0 flex-1">
        <div className="px-4 py-4">
          {current === "presets" && <PresetGallery />}
          {current === "design" && <DesignPanel />}
          {current === "image" && <ImagePanel />}
        </div>
      </ScrollArea>
    </>
  );
}
