//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DkAfsn9z.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DBdA4YFj.js", "/assets/rolldown-runtime-CbXtAM7H.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DBdA4YFj.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-sb9G684t.js"]
	}
} });
//#endregion
export { tsrStartManifest };
