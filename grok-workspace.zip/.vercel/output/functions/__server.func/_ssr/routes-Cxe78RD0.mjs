import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { r as Slot, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { S as CalendarDays, _ as ImagePlus, b as Copy, c as Phone, d as MessageCircle, f as MapPin, g as Image$1, h as LayoutGrid, i as Type, l as Palette, m as Link2, n as Wifi, o as Shuffle, p as Mail, r as UserRound, s as Printer, t as X, u as MessageSquare, v as ImageDown, x as Check, y as Download } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
import { n as encode, t as QrCodeDataType } from "../_libs/uqr.mjs";
import { i as Viewport, n as Scrollbar, r as Thumb, t as Root$1 } from "../_libs/radix-ui__react-scroll-area.mjs";
import { n as Portal, r as Provider, t as Content2 } from "../_libs/@radix-ui/react-tooltip+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Cxe78RD0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
	type,
	ref,
	className: cn("flex h-11 w-full min-w-0 rounded-md border border-border bg-elevated px-3 text-sm text-fg shadow-none outline-none transition-colors placeholder:text-subtle focus-visible:border-border-strong focus-visible:ring-2 focus-visible:ring-accent/30 disabled:opacity-50", className),
	...props
}));
Input.displayName = "Input";
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("text-xs font-medium tracking-wide text-muted", className),
	...props
}));
Label.displayName = "Label";
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
	ref,
	className: cn("flex min-h-24 w-full rounded-md border border-border bg-elevated px-3 py-2.5 text-sm text-fg outline-none transition-colors placeholder:text-subtle focus-visible:border-border-strong focus-visible:ring-2 focus-visible:ring-accent/30 disabled:opacity-50", className),
	...props
}));
Textarea.displayName = "Textarea";
var MODULE_SHAPES = [
	{
		id: "square",
		label: "Square"
	},
	{
		id: "rounded",
		label: "Round"
	},
	{
		id: "squircle",
		label: "Soft"
	},
	{
		id: "dots",
		label: "Dots"
	},
	{
		id: "fluid",
		label: "Fluid"
	},
	{
		id: "classy",
		label: "Classy"
	},
	{
		id: "diamond",
		label: "Diamond"
	},
	{
		id: "hex",
		label: "Hex"
	},
	{
		id: "star",
		label: "Star"
	},
	{
		id: "plus",
		label: "Plus"
	},
	{
		id: "leaf",
		label: "Leaf"
	},
	{
		id: "heart",
		label: "Heart"
	}
];
var EYE_SHAPES = [
	{
		id: "square",
		label: "Square"
	},
	{
		id: "rounded",
		label: "Round"
	},
	{
		id: "extra-rounded",
		label: "Soft"
	},
	{
		id: "circle",
		label: "Circle"
	},
	{
		id: "classy",
		label: "Classy"
	},
	{
		id: "diamond",
		label: "Diamond"
	},
	{
		id: "leaf",
		label: "Leaf"
	},
	{
		id: "hex",
		label: "Hex"
	}
];
var IMAGE_MODES = [
	{
		id: "paint",
		label: "Picture",
		hint: "Image shows through; dots carry the code"
	},
	{
		id: "mosaic",
		label: "Mosaic",
		hint: "Each tile samples the photo"
	},
	{
		id: "halftone",
		label: "Halftone",
		hint: "Dots sized from the photo"
	},
	{
		id: "backdrop",
		label: "Backdrop",
		hint: "Photo sits behind the mark"
	},
	{
		id: "logo",
		label: "Logo",
		hint: "Center emblem only"
	},
	{
		id: "none",
		label: "None",
		hint: "Style only, no photo"
	}
];
function emptyPayload() {
	return {
		kind: "url",
		url: "https://grok.com",
		text: "",
		phone: "",
		smsBody: "",
		email: "",
		emailSubject: "",
		emailBody: "",
		whatsapp: "",
		whatsappText: "",
		wifiSsid: "",
		wifiPassword: "",
		wifiType: "WPA",
		wifiHidden: false,
		lat: "",
		lng: "",
		geoLabel: "",
		firstName: "",
		lastName: "",
		org: "",
		vphone: "",
		vemail: "",
		vurl: "",
		eventTitle: "",
		eventLocation: "",
		eventStart: "",
		eventEnd: ""
	};
}
var DEFAULT_STYLE = {
	moduleShape: "fluid",
	eyeShape: "rounded",
	ballShape: "rounded",
	fg: "#141412",
	bg: "#f4f1ea",
	eyeColor: "#141412",
	ballColor: "#141412",
	gradientType: "none",
	gradientTo: "#3a3a36",
	quietZone: 2,
	moduleGap: 0,
	imageMode: "paint",
	imageOpacity: .92,
	dotScale: .56,
	contrast: .72,
	logoScale: .22,
	minVersion: 6,
	ecc: "H",
	transparentBg: false
};
var PALETTES = [
	{
		id: "ink",
		name: "Ink",
		cat: "Classic",
		fg: "#141412",
		bg: "#f4f1ea",
		eye: "#141412",
		ball: "#141412"
	},
	{
		id: "ghost",
		name: "Ghost",
		cat: "Classic",
		fg: "#f4f1ea",
		bg: "#141412",
		eye: "#f4f1ea",
		ball: "#f4f1ea"
	},
	{
		id: "newsprint",
		name: "Newsprint",
		cat: "Classic",
		fg: "#1c1916",
		bg: "#e8e0d4",
		eye: "#1c1916",
		ball: "#1c1916"
	},
	{
		id: "navy",
		name: "Navy",
		cat: "Classic",
		fg: "#0f2744",
		bg: "#f3f1ec",
		eye: "#0f2744",
		ball: "#0c1d33"
	},
	{
		id: "slate",
		name: "Slate",
		cat: "Classic",
		fg: "#3a4048",
		bg: "#eef0f2",
		eye: "#2a3036",
		ball: "#2a3036"
	},
	{
		id: "carbon",
		name: "Carbon",
		cat: "Classic",
		fg: "#e7e7e4",
		bg: "#1a1b1d",
		eye: "#e7e7e4",
		ball: "#cfd0cc"
	},
	{
		id: "ivory",
		name: "Ivory",
		cat: "Classic",
		fg: "#4a3f32",
		bg: "#f7f1e4",
		eye: "#3a3228",
		ball: "#3a3228"
	},
	{
		id: "lead",
		name: "Lead",
		cat: "Classic",
		fg: "#2b2e32",
		bg: "#d8dde2",
		eye: "#1a1c1f",
		ball: "#1a1c1f"
	},
	{
		id: "moss",
		name: "Moss",
		cat: "Nature",
		fg: "#2f4a38",
		bg: "#e8f0e6",
		eye: "#1e3326",
		ball: "#1e3326"
	},
	{
		id: "pine",
		name: "Pine",
		cat: "Nature",
		fg: "#e5efe4",
		bg: "#1c2b22",
		eye: "#e5efe4",
		ball: "#c5d8c2"
	},
	{
		id: "fern",
		name: "Fern",
		cat: "Nature",
		fg: "#3d6b4f",
		bg: "#f2f6ef",
		eye: "#2a4a36",
		ball: "#2a4a36",
		to: "#7da36a"
	},
	{
		id: "ocean",
		name: "Ocean",
		cat: "Nature",
		fg: "#164e63",
		bg: "#e8f4f8",
		eye: "#0e3a4a",
		ball: "#0e3a4a",
		to: "#1d7a8c"
	},
	{
		id: "tide",
		name: "Tide",
		cat: "Nature",
		fg: "#e6f3f4",
		bg: "#12343c",
		eye: "#e6f3f4",
		ball: "#b7d9dc"
	},
	{
		id: "coral",
		name: "Coral",
		cat: "Nature",
		fg: "#c45c4a",
		bg: "#fbf1ee",
		eye: "#8f3d32",
		ball: "#8f3d32"
	},
	{
		id: "sand",
		name: "Sand",
		cat: "Nature",
		fg: "#8a6a44",
		bg: "#f6ecd8",
		eye: "#5c452c",
		ball: "#5c452c"
	},
	{
		id: "clay",
		name: "Clay",
		cat: "Nature",
		fg: "#7a4b3a",
		bg: "#f3e6dc",
		eye: "#5a3226",
		ball: "#5a3226"
	},
	{
		id: "dusk",
		name: "Dusk",
		cat: "Sky",
		fg: "#2c3654",
		bg: "#ece8f0",
		eye: "#1b2238",
		ball: "#1b2238",
		to: "#5a6b8a"
	},
	{
		id: "dawn",
		name: "Dawn",
		cat: "Sky",
		fg: "#c46a4a",
		bg: "#fdeee4",
		eye: "#8d4430",
		ball: "#8d4430",
		to: "#e8a87a"
	},
	{
		id: "storm",
		name: "Storm",
		cat: "Sky",
		fg: "#4a5564",
		bg: "#d9e2ec",
		eye: "#2d3642",
		ball: "#2d3642"
	},
	{
		id: "fog",
		name: "Fog",
		cat: "Sky",
		fg: "#6b7280",
		bg: "#f3f4f6",
		eye: "#374151",
		ball: "#374151"
	},
	{
		id: "glacier",
		name: "Glacier",
		cat: "Sky",
		fg: "#3d6a78",
		bg: "#eaf4f6",
		eye: "#1f4450",
		ball: "#1f4450",
		to: "#7eb0bd"
	},
	{
		id: "horizon",
		name: "Horizon",
		cat: "Sky",
		fg: "#2a4a62",
		bg: "#f4efe6",
		eye: "#1a3142",
		ball: "#1a3142",
		to: "#d9845c"
	},
	{
		id: "noon",
		name: "Noon",
		cat: "Sky",
		fg: "#1e5f8a",
		bg: "#eef6fb",
		eye: "#13405e",
		ball: "#13405e"
	},
	{
		id: "mist",
		name: "Mist",
		cat: "Sky",
		fg: "#5c6d70",
		bg: "#e7eeef",
		eye: "#3a4749",
		ball: "#3a4749"
	},
	{
		id: "ember",
		name: "Ember",
		cat: "Ember",
		fg: "#c45c2a",
		bg: "#1a120e",
		eye: "#e8a060",
		ball: "#f3d2a6"
	},
	{
		id: "coal",
		name: "Coal",
		cat: "Ember",
		fg: "#f0dcc4",
		bg: "#1c1612",
		eye: "#f0dcc4",
		ball: "#d4b896"
	},
	{
		id: "rust",
		name: "Rust",
		cat: "Ember",
		fg: "#a84832",
		bg: "#f6ebe4",
		eye: "#6e2e20",
		ball: "#6e2e20"
	},
	{
		id: "copper",
		name: "Copper",
		cat: "Ember",
		fg: "#b87333",
		bg: "#1a1410",
		eye: "#e0a060",
		ball: "#c88848"
	},
	{
		id: "brick",
		name: "Brick",
		cat: "Ember",
		fg: "#8f3a32",
		bg: "#f7eeea",
		eye: "#5c241e",
		ball: "#5c241e"
	},
	{
		id: "wine",
		name: "Wine",
		cat: "Ember",
		fg: "#6e2436",
		bg: "#f8eef1",
		eye: "#4a1824",
		ball: "#4a1824"
	},
	{
		id: "cherry",
		name: "Cherry",
		cat: "Ember",
		fg: "#b03040",
		bg: "#fdecee",
		eye: "#7a1e2a",
		ball: "#7a1e2a"
	},
	{
		id: "maple",
		name: "Maple",
		cat: "Ember",
		fg: "#c46b2e",
		bg: "#fbf1e6",
		eye: "#8a4518",
		ball: "#8a4518"
	},
	{
		id: "film",
		name: "Film",
		cat: "Studio",
		fg: "#22201c",
		bg: "#d9d2c5",
		eye: "#22201c",
		ball: "#22201c"
	},
	{
		id: "sepia",
		name: "Sepia",
		cat: "Studio",
		fg: "#5c4632",
		bg: "#efe3cd",
		eye: "#3e2e20",
		ball: "#3e2e20"
	},
	{
		id: "chrome",
		name: "Chrome",
		cat: "Studio",
		fg: "#9aa3ad",
		bg: "#1c1e22",
		eye: "#d0d6dc",
		ball: "#eceff2"
	},
	{
		id: "brass",
		name: "Brass",
		cat: "Studio",
		fg: "#c6a25a",
		bg: "#16140f",
		eye: "#e8d09a",
		ball: "#f0e4c0"
	},
	{
		id: "velvet",
		name: "Velvet",
		cat: "Studio",
		fg: "#d8d0c8",
		bg: "#241c1c",
		eye: "#d8d0c8",
		ball: "#b8b0a8"
	},
	{
		id: "porcelain",
		name: "Porcelain",
		cat: "Studio",
		fg: "#4a5a62",
		bg: "#f4f6f5",
		eye: "#2f3c42",
		ball: "#2f3c42"
	},
	{
		id: "onyx",
		name: "Onyx",
		cat: "Studio",
		fg: "#0e0e0e",
		bg: "#f7f7f5",
		eye: "#0e0e0e",
		ball: "#0e0e0e"
	},
	{
		id: "pearl",
		name: "Pearl",
		cat: "Studio",
		fg: "#8a8680",
		bg: "#f8f5f0",
		eye: "#3a3834",
		ball: "#3a3834"
	},
	{
		id: "electric",
		name: "Electric",
		cat: "Pulse",
		fg: "#1d9bf0",
		bg: "#0b1220",
		eye: "#e8f4fc",
		ball: "#1d9bf0"
	},
	{
		id: "cyan",
		name: "Cyan",
		cat: "Pulse",
		fg: "#22c3d6",
		bg: "#07151a",
		eye: "#dff6fa",
		ball: "#22c3d6"
	},
	{
		id: "mint",
		name: "Mint",
		cat: "Pulse",
		fg: "#3dba8b",
		bg: "#0d1a16",
		eye: "#d8f5ea",
		ball: "#3dba8b"
	},
	{
		id: "lime",
		name: "Lime",
		cat: "Pulse",
		fg: "#b6d66c",
		bg: "#14180c",
		eye: "#eef6d4",
		ball: "#b6d66c"
	},
	{
		id: "tangerine",
		name: "Tangerine",
		cat: "Pulse",
		fg: "#f08a3a",
		bg: "#1a120c",
		eye: "#fde4cc",
		ball: "#f08a3a"
	},
	{
		id: "cobalt",
		name: "Cobalt",
		cat: "Pulse",
		fg: "#3a6fd6",
		bg: "#0c1220",
		eye: "#d6e4fa",
		ball: "#3a6fd6"
	},
	{
		id: "berry",
		name: "Berry",
		cat: "Pulse",
		fg: "#d44a6a",
		bg: "#1a0e14",
		eye: "#fad8e0",
		ball: "#d44a6a"
	},
	{
		id: "ice",
		name: "Ice",
		cat: "Pulse",
		fg: "#a8d4e8",
		bg: "#102028",
		eye: "#eef6fa",
		ball: "#a8d4e8"
	}
];
var KIT_POOL = [
	{
		key: "cut",
		label: "Cut",
		module: "square",
		eye: "square",
		ball: "square"
	},
	{
		key: "drop",
		label: "Drop",
		module: "dots",
		eye: "circle",
		ball: "circle",
		gap: .04
	},
	{
		key: "bloom",
		label: "Bloom",
		module: "fluid",
		eye: "extra-rounded",
		ball: "rounded"
	},
	{
		key: "gem",
		label: "Gem",
		module: "diamond",
		eye: "diamond",
		ball: "diamond",
		gap: .06
	},
	{
		key: "petal",
		label: "Petal",
		module: "leaf",
		eye: "leaf",
		ball: "circle"
	},
	{
		key: "nova",
		label: "Nova",
		module: "star",
		eye: "circle",
		ball: "circle",
		gap: .05
	},
	{
		key: "plus",
		label: "Plus",
		module: "plus",
		eye: "rounded",
		ball: "square",
		gap: .08
	},
	{
		key: "classy",
		label: "Classy",
		module: "classy",
		eye: "classy",
		ball: "rounded"
	},
	{
		key: "hex",
		label: "Hex",
		module: "hex",
		eye: "hex",
		ball: "hex",
		gap: .04
	},
	{
		key: "heart",
		label: "Heart",
		module: "heart",
		eye: "rounded",
		ball: "circle",
		gap: .06
	},
	{
		key: "soft",
		label: "Soft",
		module: "rounded",
		eye: "rounded",
		ball: "rounded",
		gap: .05
	},
	{
		key: "puff",
		label: "Puff",
		module: "squircle",
		eye: "extra-rounded",
		ball: "circle",
		gap: .03
	}
];
function styleFrom(p, kit, featured) {
	const useGrad = Boolean(p.to) && (kit.key === "bloom" || kit.key === "soft" || kit.key === "puff");
	return {
		...DEFAULT_STYLE,
		moduleShape: kit.module,
		eyeShape: kit.eye,
		ballShape: kit.ball,
		fg: p.fg,
		bg: p.bg,
		eyeColor: p.eye,
		ballColor: p.ball,
		gradientType: useGrad ? "diagonal" : "none",
		gradientTo: p.to ?? p.fg,
		moduleGap: kit.gap ?? 0,
		imageMode: featured ? "paint" : "paint",
		quietZone: 2
	};
}
function buildPresets() {
	const list = [];
	PALETTES.forEach((palette, i) => {
		[
			0,
			4,
			8
		].map((off) => KIT_POOL[(i + off) % KIT_POOL.length]).forEach((kit, ki) => {
			const featured = i < 4 && ki === 0;
			list.push({
				id: `${palette.id}-${kit.key}`,
				name: `${palette.name} ${kit.label}`,
				category: palette.cat,
				featured,
				style: styleFrom(palette, kit, featured)
			});
		});
	});
	return list;
}
var PRESETS = buildPresets();
var PRESET_CATEGORIES = ["All", ...Array.from(new Set(PRESETS.map((p) => p.category)))];
function getPreset(id) {
	return PRESETS.find((p) => p.id === id);
}
var SAMPLE_IMAGES = [
	{
		id: "ink",
		name: "Ink",
		src: "/samples/ink.jpg"
	},
	{
		id: "peony",
		name: "Peony",
		src: "/samples/peony.jpg"
	},
	{
		id: "cat",
		name: "Tabby",
		src: "/samples/cat.jpg"
	},
	{
		id: "lake",
		name: "Lake",
		src: "/samples/lake.jpg"
	},
	{
		id: "arch",
		name: "Stairs",
		src: "/samples/arch.jpg"
	},
	{
		id: "waves",
		name: "Waves",
		src: "/samples/waves.jpg"
	}
];
var HISTORY_KEY = "beacon-history-v1";
function persist(history) {
	try {
		const slim = history.slice(0, 12).map((h) => ({
			...h,
			imageUrl: h.imageUrl?.startsWith("blob:") ? null : h.imageUrl
		}));
		localStorage.setItem(HISTORY_KEY, JSON.stringify(slim));
	} catch {}
}
var useStudio = create((set, get) => ({
	payload: emptyPayload(),
	style: { ...DEFAULT_STYLE },
	imageUrl: "/samples/ink.jpg",
	logoUrl: null,
	presetId: null,
	category: "All",
	scanText: null,
	scanOk: null,
	error: null,
	history: [],
	mobileTab: "content",
	setKind: (kind) => set((s) => ({ payload: {
		...s.payload,
		kind
	} })),
	patchPayload: (patch) => set((s) => ({ payload: {
		...s.payload,
		...patch
	} })),
	patchStyle: (patch) => set((s) => ({
		style: {
			...s.style,
			...patch
		},
		presetId: null
	})),
	applyPreset: (id) => {
		const preset = getPreset(id);
		if (!preset) return;
		const current = get();
		const keepMode = current.imageUrl && current.style.imageMode !== "none" ? current.style.imageMode : current.imageUrl ? "paint" : preset.style.imageMode;
		set({
			presetId: id,
			style: {
				...preset.style,
				imageMode: keepMode,
				minVersion: current.style.minVersion,
				dotScale: current.style.dotScale,
				contrast: current.style.contrast,
				logoScale: current.style.logoScale,
				quietZone: current.style.quietZone,
				transparentBg: current.style.transparentBg,
				ecc: current.style.ecc
			}
		});
	},
	setImageUrl: (url) => set((s) => ({
		imageUrl: url,
		style: {
			...s.style,
			imageMode: url ? s.style.imageMode === "none" ? "paint" : s.style.imageMode : "none"
		}
	})),
	setLogoUrl: (url) => set({ logoUrl: url }),
	setCategory: (category) => set({ category }),
	setScan: (scanOk, scanText) => set({
		scanOk,
		scanText
	}),
	setError: (error) => set({ error }),
	setMobileTab: (mobileTab) => set({ mobileTab }),
	pushHistory: (item) => {
		const history = [{
			...item,
			id: `${Date.now()}`,
			createdAt: Date.now()
		}, ...get().history].slice(0, 12);
		set({ history });
		persist(history);
	},
	loadHistoryItem: (id) => {
		const item = get().history.find((h) => h.id === id);
		if (!item) return;
		set({
			payload: item.payload,
			style: item.style,
			imageUrl: item.imageUrl,
			presetId: null
		});
	},
	hydrateHistory: () => {
		try {
			const raw = localStorage.getItem(HISTORY_KEY);
			if (!raw) return;
			const parsed = JSON.parse(raw);
			if (Array.isArray(parsed)) set({ history: parsed.slice(0, 12) });
		} catch {}
	}
}));
var KINDS = [
	{
		id: "url",
		label: "Link",
		icon: Link2
	},
	{
		id: "text",
		label: "Text",
		icon: Type
	},
	{
		id: "phone",
		label: "Phone",
		icon: Phone
	},
	{
		id: "sms",
		label: "SMS",
		icon: MessageSquare
	},
	{
		id: "email",
		label: "Email",
		icon: Mail
	},
	{
		id: "whatsapp",
		label: "WA",
		icon: MessageCircle
	},
	{
		id: "wifi",
		label: "Wi-Fi",
		icon: Wifi
	},
	{
		id: "geo",
		label: "Place",
		icon: MapPin
	},
	{
		id: "vcard",
		label: "Contact",
		icon: UserRound
	},
	{
		id: "event",
		label: "Event",
		icon: CalendarDays
	}
];
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
function ContentPanel() {
	const payload = useStudio((s) => s.payload);
	const setKind = useStudio((s) => s.setKind);
	const patch = useStudio((s) => s.patchPayload);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs font-medium tracking-wide text-muted",
				children: "Opens"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-[repeat(5,minmax(0,1fr))] gap-1.5",
				children: KINDS.map((k) => {
					const Icon = k.icon;
					const on = payload.kind === k.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						title: k.label,
						onClick: () => setKind(k.id),
						className: cn("flex h-11 min-w-0 flex-col items-center justify-center overflow-hidden rounded-md border px-0.5 text-[10px] font-medium transition-colors", on ? "border-accent bg-accent text-accent-fg" : "border-border bg-elevated text-muted hover:bg-surface hover:text-fg"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "mb-0.5 size-3.5" }), k.label]
					}, k.id);
				})
			})] }),
			payload.kind === "url" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Website or any URL",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: payload.url,
					placeholder: "https://",
					inputMode: "url",
					autoCapitalize: "off",
					onChange: (e) => patch({ url: e.target.value })
				})
			}),
			payload.kind === "text" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Plain text",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: payload.text,
					placeholder: "Write anything",
					onChange: (e) => patch({ text: e.target.value })
				})
			}),
			payload.kind === "phone" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Phone number",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: payload.phone,
					placeholder: "+1 555 0100",
					inputMode: "tel",
					onChange: (e) => patch({ phone: e.target.value })
				})
			}),
			payload.kind === "sms" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Phone number",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: payload.phone,
					placeholder: "+1 555 0100",
					inputMode: "tel",
					onChange: (e) => patch({ phone: e.target.value })
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Message",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: payload.smsBody,
					placeholder: "Optional message",
					onChange: (e) => patch({ smsBody: e.target.value })
				})
			})] }),
			payload.kind === "email" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "To",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: payload.email,
						placeholder: "name@studio.com",
						inputMode: "email",
						onChange: (e) => patch({ email: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Subject",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: payload.emailSubject,
						onChange: (e) => patch({ emailSubject: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Body",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: payload.emailBody,
						onChange: (e) => patch({ emailBody: e.target.value })
					})
				})
			] }),
			payload.kind === "whatsapp" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "WhatsApp number",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: payload.whatsapp,
					placeholder: "15550100",
					inputMode: "tel",
					onChange: (e) => patch({ whatsapp: e.target.value })
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Prefilled message",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: payload.whatsappText,
					onChange: (e) => patch({ whatsappText: e.target.value })
				})
			})] }),
			payload.kind === "wifi" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Network name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: payload.wifiSsid,
						placeholder: "SSID",
						onChange: (e) => patch({ wifiSsid: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Password",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "text",
						value: payload.wifiPassword,
						placeholder: payload.wifiType === "nopass" ? "None" : "Password",
						disabled: payload.wifiType === "nopass",
						onChange: (e) => patch({ wifiPassword: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-1.5",
					children: [
						"WPA",
						"WEP",
						"nopass"
					].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => patch({ wifiType: t }),
						className: cn("h-11 rounded-md border text-xs font-medium", payload.wifiType === t ? "border-accent bg-accent text-accent-fg" : "border-border bg-elevated text-muted"),
						children: t === "nopass" ? "Open" : t
					}, t))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex h-11 items-center justify-between rounded-md border border-border bg-elevated px-3 text-sm",
					children: ["Hidden network", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: payload.wifiHidden,
						onChange: (e) => patch({ wifiHidden: e.target.checked }),
						className: "size-4 accent-accent"
					})]
				})
			] }),
			payload.kind === "geo" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Latitude",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: payload.lat,
							placeholder: "37.78",
							inputMode: "decimal",
							onChange: (e) => patch({ lat: e.target.value })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Longitude",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: payload.lng,
							placeholder: "-122.41",
							inputMode: "decimal",
							onChange: (e) => patch({ lng: e.target.value })
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Label",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: payload.geoLabel,
						placeholder: "Optional place name",
						onChange: (e) => patch({ geoLabel: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 rounded-md border border-border bg-surface text-sm text-fg hover:bg-surface-hover",
					onClick: () => {
						if (!navigator.geolocation) return;
						navigator.geolocation.getCurrentPosition((pos) => {
							patch({
								lat: pos.coords.latitude.toFixed(6),
								lng: pos.coords.longitude.toFixed(6)
							});
						});
					},
					children: "Use current location"
				})
			] }),
			payload.kind === "vcard" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "First name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: payload.firstName,
							onChange: (e) => patch({ firstName: e.target.value })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Last name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: payload.lastName,
							onChange: (e) => patch({ lastName: e.target.value })
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Organization",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: payload.org,
						onChange: (e) => patch({ org: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Phone",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: payload.vphone,
						inputMode: "tel",
						onChange: (e) => patch({ vphone: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Email",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: payload.vemail,
						inputMode: "email",
						onChange: (e) => patch({ vemail: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Website",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: payload.vurl,
						onChange: (e) => patch({ vurl: e.target.value })
					})
				})
			] }),
			payload.kind === "event" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Title",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: payload.eventTitle,
						placeholder: "Studio opening",
						onChange: (e) => patch({ eventTitle: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Location",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: payload.eventLocation,
						onChange: (e) => patch({ eventLocation: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Starts",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "datetime-local",
						value: payload.eventStart,
						onChange: (e) => patch({ eventStart: e.target.value })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Ends",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "datetime-local",
						value: payload.eventEnd,
						onChange: (e) => patch({ eventEnd: e.target.value })
					})
				})
			] })
		]
	});
}
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex min-h-11 w-full touch-none select-none items-center", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-surface",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-accent" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full border border-border-strong bg-accent shadow-sm outline-none focus-visible:ring-2 focus-visible:ring-accent/40" })]
}));
Slider.displayName = "Slider";
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
	ref,
	className: cn("peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border border-border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40 data-[state=checked]:bg-accent data-[state=unchecked]:bg-surface", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block size-5 translate-x-0.5 rounded-full bg-fg transition-transform data-[state=checked]:translate-x-[22px] data-[state=checked]:bg-accent-fg" })
}));
Switch.displayName = "Switch";
function ColorField({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex items-center gap-2 rounded-md border border-border bg-elevated px-2 py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "color",
				value,
				onChange: (e) => onChange(e.target.value),
				className: "size-8 shrink-0 cursor-pointer rounded-sm"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "min-w-0 flex-1 text-xs text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-[10px] uppercase text-subtle",
				children: value
			})
		]
	});
}
function DesignPanel() {
	const style = useStudio((s) => s.style);
	const patch = useStudio((s) => s.patchStyle);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs font-medium tracking-wide text-muted",
				children: "Module shape"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4 gap-1.5",
				children: MODULE_SHAPES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => patch({ moduleShape: s.id }),
					className: cn("h-11 rounded-md border text-[11px] font-medium", style.moduleShape === s.id ? "border-accent bg-accent text-accent-fg" : "border-border bg-elevated text-muted hover:text-fg"),
					children: s.label
				}, s.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs font-medium tracking-wide text-muted",
				children: "Finder eyes"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4 gap-1.5",
				children: EYE_SHAPES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => patch({ eyeShape: s.id }),
					className: cn("h-11 rounded-md border text-[11px] font-medium", style.eyeShape === s.id ? "border-accent bg-accent text-accent-fg" : "border-border bg-elevated text-muted hover:text-fg"),
					children: s.label
				}, s.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs font-medium tracking-wide text-muted",
				children: "Eye balls"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4 gap-1.5",
				children: EYE_SHAPES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => patch({ ballShape: s.id }),
					className: cn("h-11 rounded-md border text-[11px] font-medium", style.ballShape === s.id ? "border-accent bg-accent text-accent-fg" : "border-border bg-elevated text-muted hover:text-fg"),
					children: s.label
				}, s.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted",
						children: "Colors"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
						label: "Modules",
						value: style.fg,
						onChange: (fg) => patch({ fg })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
						label: "Background",
						value: style.bg,
						onChange: (bg) => patch({ bg })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
						label: "Eyes",
						value: style.eyeColor,
						onChange: (eyeColor) => patch({ eyeColor })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
						label: "Balls",
						value: style.ballColor,
						onChange: (ballColor) => patch({ ballColor })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
						label: "Gradient to",
						value: style.gradientTo,
						onChange: (gradientTo) => patch({ gradientTo })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs font-medium tracking-wide text-muted",
				children: "Gradient"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4 gap-1.5",
				children: [
					"none",
					"linear",
					"diagonal",
					"radial"
				].map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => patch({ gradientType: g }),
					className: cn("h-11 rounded-md border text-[11px] font-medium capitalize", style.gradientType === g ? "border-accent bg-accent text-accent-fg" : "border-border bg-elevated text-muted hover:text-fg"),
					children: g === "none" ? "Solid" : g
				}, g))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Quiet zone" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs tabular-nums text-subtle",
							children: style.quietZone
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: 1,
						max: 6,
						step: 1,
						value: [style.quietZone],
						onValueChange: ([v]) => patch({ quietZone: v ?? 2 })
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Module gap" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs tabular-nums text-subtle",
							children: [Math.round(style.moduleGap * 100), "%"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: 0,
						max: .28,
						step: .01,
						value: [style.moduleGap],
						onValueChange: ([v]) => patch({ moduleGap: v ?? 0 })
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium tracking-wide text-muted",
						children: "Error correction"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-4 gap-1.5",
						children: [
							"L",
							"M",
							"Q",
							"H"
						].map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => patch({ ecc: e }),
							className: cn("h-11 rounded-md border text-xs font-medium", style.ecc === e ? "border-accent bg-accent text-accent-fg" : "border-border bg-elevated text-muted"),
							children: e
						}, e))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex h-11 items-center justify-between rounded-md border border-border bg-elevated px-3 text-sm",
						children: ["Transparent background", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: style.transparentBg,
							onCheckedChange: (transparentBg) => patch({ transparentBg })
						})]
					})
				]
			})
		]
	});
}
function readFile(file, onUrl) {
	onUrl(URL.createObjectURL(file));
}
function ImagePanel() {
	const imageUrl = useStudio((s) => s.imageUrl);
	const logoUrl = useStudio((s) => s.logoUrl);
	const style = useStudio((s) => s.style);
	const setImageUrl = useStudio((s) => s.setImageUrl);
	const setLogoUrl = useStudio((s) => s.setLogoUrl);
	const patchStyle = useStudio((s) => s.patchStyle);
	const artRef = (0, import_react.useRef)(null);
	const logoRef = (0, import_react.useRef)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-xs font-medium tracking-wide text-muted",
					children: "Picture"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => artRef.current?.click(),
					onDragOver: (e) => e.preventDefault(),
					onDrop: (e) => {
						e.preventDefault();
						const file = e.dataTransfer.files?.[0];
						if (file?.type.startsWith("image/")) readFile(file, setImageUrl);
					},
					className: "flex min-h-32 w-full flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-border-strong bg-elevated px-4 py-6 text-center transition-colors hover:bg-surface",
					children: [
						imageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: imageUrl,
							alt: "Source",
							className: "h-24 w-24 rounded-md object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-6 text-muted" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-fg",
							children: "Drop a photo or browse"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted",
							children: "Turns into a working QR code"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: artRef,
					type: "file",
					accept: "image/*",
					className: "hidden",
					onChange: (e) => {
						const file = e.target.files?.[0];
						if (file) readFile(file, setImageUrl);
						e.target.value = "";
					}
				}),
				imageUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "mt-2 inline-flex h-9 items-center gap-1 rounded-sm px-2 text-xs text-muted hover:text-fg",
					onClick: () => setImageUrl(null),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" }), "Remove picture"]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs font-medium tracking-wide text-muted",
				children: "Try a sample"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-6 gap-1.5",
				children: SAMPLE_IMAGES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					title: s.name,
					onClick: () => setImageUrl(s.src),
					className: cn("aspect-square overflow-hidden rounded-md border", imageUrl === s.src ? "border-accent" : "border-border"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: s.src,
						alt: s.name,
						className: "size-full object-cover"
					})
				}, s.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs font-medium tracking-wide text-muted",
				children: "Picture treatment"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-1.5",
				children: IMAGE_MODES.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					title: m.hint,
					disabled: !imageUrl && m.id !== "none",
					onClick: () => patchStyle({ imageMode: m.id }),
					className: cn("h-11 rounded-md border text-xs font-medium disabled:opacity-40", style.imageMode === m.id ? "border-accent bg-accent text-accent-fg" : "border-border bg-elevated text-muted hover:text-fg"),
					children: m.label
				}, m.id))
			})] }),
			(style.imageMode === "paint" || style.imageMode === "halftone") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-1 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Dot weight" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs tabular-nums text-subtle",
					children: [Math.round(style.dotScale * 100), "%"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
				min: .28,
				max: .72,
				step: .01,
				value: [style.dotScale],
				onValueChange: ([v]) => patchStyle({ dotScale: v ?? .46 })
			})] }),
			style.imageMode === "mosaic" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-1 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Contrast lock" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs tabular-nums text-subtle",
					children: [Math.round(style.contrast * 100), "%"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
				min: .35,
				max: 1,
				step: .01,
				value: [style.contrast],
				onValueChange: ([v]) => patchStyle({ contrast: v ?? .72 })
			})] }),
			style.imageMode === "backdrop" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-1 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Photo opacity" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs tabular-nums text-subtle",
					children: [Math.round(style.imageOpacity * 100), "%"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
				min: .15,
				max: 1,
				step: .01,
				value: [style.imageOpacity],
				onValueChange: ([v]) => patchStyle({ imageOpacity: v ?? .9 })
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-1 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Detail (version)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs tabular-nums text-subtle",
						children: style.minVersion
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 2,
					max: 12,
					step: 1,
					value: [style.minVersion],
					onValueChange: ([v]) => patchStyle({ minVersion: v ?? 6 })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-subtle",
					children: "Higher detail keeps more of the photo."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-xs font-medium tracking-wide text-muted",
					children: "Center logo"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => logoRef.current?.click(),
							className: "flex size-14 items-center justify-center overflow-hidden rounded-md border border-border bg-elevated",
							children: logoUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: logoUrl,
								alt: "Logo",
								className: "size-full object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4 text-muted" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-1 flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Logo size" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs tabular-nums text-subtle",
									children: [Math.round(style.logoScale * 100), "%"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								min: .12,
								max: .3,
								step: .01,
								value: [style.logoScale],
								onValueChange: ([v]) => patchStyle({ logoScale: v ?? .22 })
							})]
						}),
						logoUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "size-9 text-muted hover:text-fg",
							onClick: () => setLogoUrl(null),
							"aria-label": "Remove logo",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: logoRef,
					type: "file",
					accept: "image/*",
					className: "hidden",
					onChange: (e) => {
						const file = e.target.files?.[0];
						if (file) readFile(file, setLogoUrl);
						e.target.value = "";
					}
				})
			] })
		]
	});
}
var imageCache = /* @__PURE__ */ new Map();
function loadImage(url) {
	const hit = imageCache.get(url);
	if (hit?.complete && hit.naturalWidth > 0) return Promise.resolve(hit);
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.crossOrigin = "anonymous";
		img.onload = () => {
			imageCache.set(url, img);
			resolve(img);
		};
		img.onerror = () => reject(/* @__PURE__ */ new Error("Could not load image"));
		img.src = url;
	});
}
function coverDraw(ctx, img, x, y, w, h, iw, ih) {
	const scale = Math.max(w / iw, h / ih);
	const dw = iw * scale;
	const dh = ih * scale;
	ctx.drawImage(img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
}
function roundedRect(ctx, x, y, w, h, tl, tr, br, bl) {
	const ctl = Math.max(0, tl);
	const ctr = Math.max(0, tr);
	const cbr = Math.max(0, br);
	const cbl = Math.max(0, bl);
	ctx.beginPath();
	ctx.moveTo(x + ctl, y);
	ctx.lineTo(x + w - ctr, y);
	ctx.quadraticCurveTo(x + w, y, x + w, y + ctr);
	ctx.lineTo(x + w, y + h - cbr);
	ctx.quadraticCurveTo(x + w, y + h, x + w - cbr, y + h);
	ctx.lineTo(x + cbl, y + h);
	ctx.quadraticCurveTo(x, y + h, x, y + h - cbl);
	ctx.lineTo(x, y + ctl);
	ctx.quadraticCurveTo(x, y, x + ctl, y);
	ctx.closePath();
}
function starPath(ctx, cx, cy, r, points = 5) {
	const inner = r * .42;
	ctx.beginPath();
	for (let i = 0; i < points * 2; i++) {
		const ang = Math.PI / points * i - Math.PI / 2;
		const rad = i % 2 === 0 ? r : inner;
		const x = cx + Math.cos(ang) * rad;
		const y = cy + Math.sin(ang) * rad;
		if (i === 0) ctx.moveTo(x, y);
		else ctx.lineTo(x, y);
	}
	ctx.closePath();
}
function hexPath(ctx, cx, cy, r) {
	ctx.beginPath();
	for (let i = 0; i < 6; i++) {
		const a = Math.PI / 3 * i - Math.PI / 6;
		const x = cx + Math.cos(a) * r;
		const y = cy + Math.sin(a) * r;
		if (i === 0) ctx.moveTo(x, y);
		else ctx.lineTo(x, y);
	}
	ctx.closePath();
}
function heartPath(ctx, cx, cy, s) {
	const w = s;
	const h = s;
	ctx.beginPath();
	ctx.moveTo(cx, cy + h * .3);
	ctx.bezierCurveTo(cx, cy + h * .08, cx - w * .5, cy - h * .28, cx - w * .5, cy - h * .05);
	ctx.bezierCurveTo(cx - w * .5, cy + h * .18, cx, cy + h * .32, cx, cy + h * .52);
	ctx.bezierCurveTo(cx, cy + h * .32, cx + w * .5, cy + h * .18, cx + w * .5, cy - h * .05);
	ctx.bezierCurveTo(cx + w * .5, cy - h * .28, cx, cy + h * .08, cx, cy + h * .3);
	ctx.closePath();
}
function plusPath(ctx, x, y, s) {
	const t = s * .34;
	const o = (s - t) / 2;
	ctx.beginPath();
	ctx.moveTo(x + o, y);
	ctx.lineTo(x + o + t, y);
	ctx.lineTo(x + o + t, y + o);
	ctx.lineTo(x + s, y + o);
	ctx.lineTo(x + s, y + o + t);
	ctx.lineTo(x + o + t, y + o + t);
	ctx.lineTo(x + o + t, y + s);
	ctx.lineTo(x + o, y + s);
	ctx.lineTo(x + o, y + o + t);
	ctx.lineTo(x, y + o + t);
	ctx.lineTo(x, y + o);
	ctx.lineTo(x + o, y + o);
	ctx.closePath();
}
function drawModuleShape(ctx, x, y, s, shape, neighbors) {
	const cx = x + s / 2;
	const cy = y + s / 2;
	switch (shape) {
		case "square":
			ctx.fillRect(x, y, s, s);
			return;
		case "rounded":
			roundedRect(ctx, x, y, s, s, s * .28, s * .28, s * .28, s * .28);
			ctx.fill();
			return;
		case "squircle":
			roundedRect(ctx, x, y, s, s, s * .42, s * .42, s * .42, s * .42);
			ctx.fill();
			return;
		case "dots":
			ctx.beginPath();
			ctx.arc(cx, cy, s * .46, 0, Math.PI * 2);
			ctx.fill();
			return;
		case "diamond":
			ctx.beginPath();
			ctx.moveTo(cx, y);
			ctx.lineTo(x + s, cy);
			ctx.lineTo(cx, y + s);
			ctx.lineTo(x, cy);
			ctx.closePath();
			ctx.fill();
			return;
		case "star":
			starPath(ctx, cx, cy, s * .5);
			ctx.fill();
			return;
		case "plus":
			plusPath(ctx, x, y, s);
			ctx.fill();
			return;
		case "classy":
			roundedRect(ctx, x, y, s, s, 0, s * .55, 0, s * .55);
			ctx.fill();
			return;
		case "leaf":
			roundedRect(ctx, x, y, s, s, s * .62, 0, s * .62, 0);
			ctx.fill();
			return;
		case "hex":
			hexPath(ctx, cx, cy, s * .52);
			ctx.fill();
			return;
		case "heart":
			heartPath(ctx, cx, cy - s * .04, s * .78);
			ctx.fill();
			return;
		case "fluid": {
			const n = neighbors;
			const r = s * .52;
			roundedRect(ctx, x, y, s, s, n && (n.n || n.w) ? 0 : r, n && (n.n || n.e) ? 0 : r, n && (n.s || n.e) ? 0 : r, n && (n.s || n.w) ? 0 : r);
			ctx.fill();
			return;
		}
		default: ctx.fillRect(x, y, s, s);
	}
}
function eyeRadii(shape, s) {
	switch (shape) {
		case "square": return [
			0,
			0,
			0,
			0
		];
		case "rounded": return [
			s * .18,
			s * .18,
			s * .18,
			s * .18
		];
		case "extra-rounded": return [
			s * .32,
			s * .32,
			s * .32,
			s * .32
		];
		case "circle": return [
			s * .5,
			s * .5,
			s * .5,
			s * .5
		];
		case "classy": return [
			0,
			s * .38,
			0,
			s * .38
		];
		case "leaf": return [
			s * .42,
			0,
			s * .42,
			0
		];
		case "diamond": return [
			0,
			0,
			0,
			0
		];
		case "hex": return [
			0,
			0,
			0,
			0
		];
		default: return [
			s * .18,
			s * .18,
			s * .18,
			s * .18
		];
	}
}
function drawLayer(ctx, x, y, s, shape, color) {
	ctx.fillStyle = color;
	if (shape === "diamond") {
		ctx.beginPath();
		ctx.moveTo(x + s / 2, y);
		ctx.lineTo(x + s, y + s / 2);
		ctx.lineTo(x + s / 2, y + s);
		ctx.lineTo(x, y + s / 2);
		ctx.closePath();
		ctx.fill();
		return;
	}
	if (shape === "hex") {
		hexPath(ctx, x + s / 2, y + s / 2, s * .52);
		ctx.fill();
		return;
	}
	if (shape === "circle") {
		ctx.beginPath();
		ctx.arc(x + s / 2, y + s / 2, s / 2, 0, Math.PI * 2);
		ctx.fill();
		return;
	}
	const [tl, tr, br, bl] = eyeRadii(shape, s);
	roundedRect(ctx, x, y, s, s, tl, tr, br, bl);
	ctx.fill();
}
function drawEye(ctx, ox, oy, cell, eyeShape, ballShape, eyeColor, ballColor, bg) {
	drawLayer(ctx, ox, oy, cell * 7, eyeShape, eyeColor);
	const inset = cell;
	drawLayer(ctx, ox + inset, oy + inset, cell * 5, eyeShape, bg);
	const ball = cell * 3;
	drawLayer(ctx, ox + cell * 2, oy + cell * 2, ball, ballShape, ballColor);
}
function sampleGrid(img, size) {
	const c = document.createElement("canvas");
	c.width = size;
	c.height = size;
	const cx = c.getContext("2d", { willReadFrequently: true });
	if (!cx) throw new Error("canvas");
	coverDraw(cx, img, 0, 0, size, size, img.naturalWidth, img.naturalHeight);
	return {
		data: cx.getImageData(0, 0, size, size).data,
		canvas: c
	};
}
function lumAt(data, size, x, y) {
	const i = (y * size + x) * 4;
	return (data[i] * .2126 + data[i + 1] * .7152 + data[i + 2] * .0722) / 255;
}
function rgbAt(data, size, x, y) {
	const i = (y * size + x) * 4;
	return [
		data[i],
		data[i + 1],
		data[i + 2]
	];
}
function mixToward(r, g, b, dark, amount) {
	const t = Math.min(1, Math.max(0, amount));
	if (dark) return `rgb(${Math.round(r * (1 - t))},${Math.round(g * (1 - t))},${Math.round(b * (1 - t))})`;
	return `rgb(${Math.round(r + (255 - r) * t)},${Math.round(g + (255 - g) * t)},${Math.round(b + (255 - b) * t)})`;
}
function makeFill(ctx, style, x0, y0, w, h) {
	if (style.gradientType === "none") return style.fg;
	if (style.gradientType === "radial") {
		const g = ctx.createRadialGradient(x0 + w / 2, y0 + h / 2, 0, x0 + w / 2, y0 + h / 2, w * .72);
		g.addColorStop(0, style.fg);
		g.addColorStop(1, style.gradientTo);
		return g;
	}
	const g = style.gradientType === "diagonal" ? ctx.createLinearGradient(x0, y0, x0 + w, y0 + h) : ctx.createLinearGradient(x0, y0, x0 + w, y0);
	g.addColorStop(0, style.fg);
	g.addColorStop(1, style.gradientTo);
	return g;
}
function isDark(qr, x, y) {
	return Boolean(qr.data[y]?.[x]);
}
function prepareCanvas(canvas, px) {
	const dpr = typeof window !== "undefined" ? Math.min(window.devicePixelRatio || 1, 2) : 1;
	canvas.width = Math.round(px * dpr);
	canvas.height = Math.round(px * dpr);
	canvas.style.width = `${px}px`;
	canvas.style.height = `${px}px`;
	const ctx = canvas.getContext("2d", { willReadFrequently: true });
	if (!ctx) throw new Error("Canvas is not available");
	ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
	ctx.imageSmoothingEnabled = true;
	ctx.imageSmoothingQuality = "high";
	return ctx;
}
function renderQr(canvas, qr, style, opts) {
	const px = opts.pixelSize;
	const ctx = opts.exportScale ? (() => {
		canvas.width = px;
		canvas.height = px;
		canvas.style.width = `${px}px`;
		canvas.style.height = `${px}px`;
		const c = canvas.getContext("2d", { willReadFrequently: true });
		if (!c) throw new Error("Canvas is not available");
		c.setTransform(1, 0, 0, 1, 0, 0);
		c.imageSmoothingEnabled = true;
		c.imageSmoothingQuality = "high";
		return c;
	})() : prepareCanvas(canvas, px);
	const qz = Math.max(0, Math.min(8, style.quietZone));
	const cell = px / (qr.size + qz * 2);
	const origin = qz * cell;
	const body = qr.size * cell;
	const pictured = Boolean(opts.art) && style.imageMode !== "none" && style.imageMode !== "logo";
	const bg = style.transparentBg ? "rgba(0,0,0,0)" : style.bg;
	ctx.clearRect(0, 0, px, px);
	if (!style.transparentBg) {
		ctx.fillStyle = style.bg;
		ctx.fillRect(0, 0, px, px);
	}
	if (pictured && opts.art && (style.imageMode === "paint" || style.imageMode === "backdrop")) {
		ctx.save();
		ctx.beginPath();
		ctx.rect(origin, origin, body, body);
		ctx.clip();
		ctx.globalAlpha = style.imageMode === "backdrop" ? style.imageOpacity : 1;
		coverDraw(ctx, opts.art, origin, origin, body, body, opts.art.naturalWidth, opts.art.naturalHeight);
		ctx.restore();
	}
	const sampled = pictured && opts.art && (style.imageMode === "mosaic" || style.imageMode === "halftone") ? sampleGrid(opts.art, qr.size) : null;
	if (style.imageMode === "mosaic" && sampled && opts.art) {
		ctx.save();
		ctx.beginPath();
		ctx.rect(origin, origin, body, body);
		ctx.clip();
		coverDraw(ctx, sampled.canvas, origin, origin, body, body, qr.size, qr.size);
		ctx.restore();
	}
	const fill = makeFill(ctx, style, origin, origin, body, body);
	const gap = Math.max(0, Math.min(.35, style.moduleGap));
	for (let y = 0; y < qr.size; y++) for (let x = 0; x < qr.size; x++) {
		const type = qr.types[y][x];
		if (type === QrCodeDataType.Position) continue;
		const dark = isDark(qr, x, y);
		const px0 = origin + x * cell;
		const py0 = origin + y * cell;
		const pad = cell * gap * .5;
		const ms = cell - pad * 2;
		if ((type === QrCodeDataType.Function || type === QrCodeDataType.Timing || type === QrCodeDataType.Alignment) && (style.imageMode === "paint" || style.imageMode === "halftone" || style.imageMode === "mosaic" || style.imageMode === "backdrop")) {
			ctx.fillStyle = dark ? fill : style.bg;
			ctx.fillRect(px0, py0, cell, cell);
			continue;
		}
		if (style.imageMode === "mosaic" && sampled) {
			const [r, g, b] = rgbAt(sampled.data, qr.size, x, y);
			ctx.fillStyle = mixToward(r, g, b, dark, style.contrast);
			drawModuleShape(ctx, px0 + pad, py0 + pad, ms, style.moduleShape, {
				n: isDark(qr, x, y - 1),
				e: isDark(qr, x + 1, y),
				s: isDark(qr, x, y + 1),
				w: isDark(qr, x - 1, y)
			});
			continue;
		}
		if (style.imageMode === "halftone" && sampled) {
			const L = lumAt(sampled.data, qr.size, x, y);
			const minR = dark ? cell * .22 : cell * .02;
			const radius = minR + ((dark ? cell * .48 : cell * .18) - minR) * (1 - L);
			ctx.fillStyle = dark ? fill : bg;
			ctx.beginPath();
			ctx.arc(px0 + cell / 2, py0 + cell / 2, Math.max(.4, radius), 0, Math.PI * 2);
			ctx.fill();
			continue;
		}
		if (style.imageMode === "paint" && opts.art) {
			const ds = cell * (dark ? Math.max(.5, style.dotScale) : Math.max(.34, style.dotScale * .78));
			const dx = px0 + (cell - ds) / 2;
			const dy = py0 + (cell - ds) / 2;
			ctx.fillStyle = dark ? fill : style.bg;
			drawModuleShape(ctx, dx, dy, ds, style.moduleShape === "fluid" || style.moduleShape === "classy" || style.moduleShape === "heart" ? "dots" : style.moduleShape);
			continue;
		}
		if (!dark) continue;
		ctx.fillStyle = fill;
		const neighbors = style.moduleShape === "fluid" ? {
			n: isDark(qr, x, y - 1),
			e: isDark(qr, x + 1, y),
			s: isDark(qr, x, y + 1),
			w: isDark(qr, x - 1, y)
		} : void 0;
		drawModuleShape(ctx, px0 + pad, py0 + pad, ms, style.moduleShape, neighbors);
	}
	const eyeBg = style.imageMode === "paint" && opts.art ? style.bg : bg || style.bg;
	const corners = [
		[0, 0],
		[qr.size - 7, 0],
		[0, qr.size - 7]
	];
	for (const [ex, ey] of corners) drawEye(ctx, origin + ex * cell, origin + ey * cell, cell, style.eyeShape, style.ballShape, style.eyeColor, style.ballColor, eyeBg);
	const logoImg = opts.logo ?? (style.imageMode === "logo" ? opts.art : null);
	if (logoImg) {
		const logoSize = body * Math.max(.12, Math.min(.32, style.logoScale));
		const lx = origin + (body - logoSize) / 2;
		const ly = origin + (body - logoSize) / 2;
		const pad = logoSize * .12;
		ctx.fillStyle = style.bg;
		roundedRect(ctx, lx - pad * .4, ly - pad * .4, logoSize + pad * .8, logoSize + pad * .8, pad, pad, pad, pad);
		ctx.fill();
		ctx.save();
		roundedRect(ctx, lx, ly, logoSize, logoSize, pad * .6, pad * .6, pad * .6, pad * .6);
		ctx.clip();
		coverDraw(ctx, logoImg, lx, ly, logoSize, logoSize, logoImg.naturalWidth, logoImg.naturalHeight);
		ctx.restore();
	}
}
function downloadCanvasPng(canvas, filename) {
	canvas.toBlob((blob) => {
		if (!blob) return;
		const a = document.createElement("a");
		a.href = URL.createObjectURL(blob);
		a.download = filename;
		a.click();
		setTimeout(() => URL.revokeObjectURL(a.href), 1500);
	}, "image/png");
}
async function canvasPngBlob(canvas) {
	return new Promise((resolve, reject) => {
		canvas.toBlob((blob) => {
			if (blob) resolve(blob);
			else reject(/* @__PURE__ */ new Error("Could not export PNG"));
		}, "image/png");
	});
}
var THUMB = encode("BEACON", {
	ecc: "M",
	border: 0
});
function PresetThumb({ style, active, name, onPick }) {
	const [src, setSrc] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const canvas = document.createElement("canvas");
		renderQr(canvas, THUMB, {
			...style,
			imageMode: "none",
			quietZone: 1,
			transparentBg: false
		}, {
			pixelSize: 96,
			exportScale: true
		});
		setSrc(canvas.toDataURL("image/png"));
	}, [style]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onPick,
		title: name,
		className: cn("group flex min-w-0 flex-col gap-1.5 rounded-md border p-1.5 text-left transition-colors", active ? "border-accent bg-surface" : "border-border bg-elevated hover:border-border-strong"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "aspect-square overflow-hidden rounded-sm",
			style: { background: style.bg },
			children: src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src,
				alt: "",
				className: "size-full"
			}) : null
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "truncate px-0.5 text-[10px] leading-tight text-muted group-hover:text-fg",
			children: name
		})]
	});
}
function PresetGallery() {
	const category = useStudio((s) => s.category);
	const presetId = useStudio((s) => s.presetId);
	const setCategory = useStudio((s) => s.setCategory);
	const applyPreset = useStudio((s) => s.applyPreset);
	const list = category === "All" ? PRESETS : PRESETS.filter((p) => p.category === category);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1.5",
				children: PRESET_CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setCategory(c),
					className: cn("h-8 rounded-full border px-3 text-xs font-medium", category === c ? "border-accent bg-accent text-accent-fg" : "border-border bg-elevated text-muted hover:text-fg"),
					children: c
				}, c))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-subtle tabular-nums",
				children: [list.length, " presets"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2 sm:grid-cols-4 lg:grid-cols-3",
				children: list.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresetThumb, {
					style: p.style,
					name: p.name,
					active: presetId === p.id,
					onPick: () => applyPreset(p.id)
				}, p.id))
			})
		]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,color] duration-150 ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40 disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "bg-surface text-fg border border-border hover:bg-surface-hover",
			ghost: "text-fg hover:bg-surface",
			outline: "border border-border-strong bg-transparent text-fg hover:bg-surface",
			danger: "bg-danger text-fg hover:opacity-90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 rounded-sm px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11",
			"icon-sm": "size-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		ref,
		...props
	});
});
Button.displayName = "Button";
function digits(value) {
	return value.replace(/[^\d+]/g, "");
}
function wifiEscape(value) {
	return value.replace(/([\\;,:"])/g, "\\$1");
}
function icsDate(value) {
	const raw = value.trim();
	if (!raw) return "";
	const d = new Date(raw);
	if (Number.isNaN(d.getTime())) return raw.replace(/[-:]/g, "").replace(/\.\d{3}/, "");
	const p = (n) => String(n).padStart(2, "0");
	return `${d.getUTCFullYear()}${p(d.getUTCMonth() + 1)}${p(d.getUTCDate())}T${p(d.getUTCHours())}${p(d.getUTCMinutes())}${p(d.getUTCSeconds())}Z`;
}
function buildPayload(p) {
	switch (p.kind) {
		case "url": {
			const url = p.url.trim();
			if (!url) return "";
			if (/^[a-z][a-z0-9+.-]*:/i.test(url)) return url;
			return `https://${url}`;
		}
		case "text": return p.text;
		case "phone": {
			const n = digits(p.phone);
			return n ? `tel:${n}` : "";
		}
		case "sms": {
			const n = digits(p.phone);
			if (!n) return "";
			const body = p.smsBody.trim();
			return body ? `sms:${n}?body=${encodeURIComponent(body)}` : `sms:${n}`;
		}
		case "email": {
			const to = p.email.trim();
			if (!to) return "";
			const q = new URLSearchParams();
			if (p.emailSubject.trim()) q.set("subject", p.emailSubject.trim());
			if (p.emailBody.trim()) q.set("body", p.emailBody.trim());
			const qs = q.toString();
			return qs ? `mailto:${to}?${qs}` : `mailto:${to}`;
		}
		case "whatsapp": {
			const n = digits(p.whatsapp).replace(/^\+/, "");
			if (!n) return "";
			const t = p.whatsappText.trim();
			return t ? `https://wa.me/${n}?text=${encodeURIComponent(t)}` : `https://wa.me/${n}`;
		}
		case "wifi": {
			const ssid = p.wifiSsid.trim();
			if (!ssid) return "";
			const type = p.wifiType === "nopass" ? "nopass" : p.wifiType;
			const pass = type === "nopass" ? "" : p.wifiPassword;
			return `WIFI:T:${type};S:${wifiEscape(ssid)};P:${wifiEscape(pass)};H:${p.wifiHidden ? "true" : "false"};;`;
		}
		case "geo": {
			const lat = p.lat.trim();
			const lng = p.lng.trim();
			if (!lat || !lng) return "";
			const label = p.geoLabel.trim();
			return label ? `geo:${lat},${lng}?q=${encodeURIComponent(label)}` : `geo:${lat},${lng}`;
		}
		case "vcard": {
			const first = p.firstName.trim();
			const last = p.lastName.trim();
			const fn = [first, last].filter(Boolean).join(" ");
			if (!fn && !p.vphone && !p.vemail) return "";
			const lines = [
				"BEGIN:VCARD",
				"VERSION:3.0",
				`N:${last};${first};;;`,
				`FN:${fn || "Contact"}`
			];
			if (p.org.trim()) lines.push(`ORG:${p.org.trim()}`);
			if (p.vphone.trim()) lines.push(`TEL;TYPE=CELL:${digits(p.vphone)}`);
			if (p.vemail.trim()) lines.push(`EMAIL:${p.vemail.trim()}`);
			if (p.vurl.trim()) lines.push(`URL:${p.vurl.trim()}`);
			lines.push("END:VCARD");
			return lines.join("\n");
		}
		case "event": {
			const title = p.eventTitle.trim();
			if (!title) return "";
			const start = icsDate(p.eventStart);
			const end = icsDate(p.eventEnd);
			const lines = [
				"BEGIN:VCALENDAR",
				"VERSION:2.0",
				"BEGIN:VEVENT",
				`SUMMARY:${title}`
			];
			if (start) lines.push(`DTSTART:${start}`);
			if (end) lines.push(`DTEND:${end}`);
			if (p.eventLocation.trim()) lines.push(`LOCATION:${p.eventLocation.trim()}`);
			lines.push("END:VEVENT", "END:VCALENDAR");
			return lines.join("\n");
		}
		default: return "";
	}
}
function payloadLabel(p) {
	const text = buildPayload(p);
	if (!text) return "Empty";
	if (text.length <= 42) return text;
	return `${text.slice(0, 40)}…`;
}
function encodePayload(payload, style) {
	const text = buildPayload(payload).trim() || "https://grok.com";
	const pictured = style.imageMode !== "none";
	return encode(text, {
		ecc: pictured ? "H" : style.ecc,
		boostEcc: pictured,
		minVersion: pictured ? Math.max(style.minVersion, 4) : 1,
		border: 0
	});
}
function tryEncodePayload(payload, style) {
	try {
		return {
			ok: true,
			qr: encodePayload(payload, style)
		};
	} catch (err) {
		return {
			ok: false,
			error: err instanceof Error ? err.message : "Could not encode this content."
		};
	}
}
async function verifyQr(canvas) {
	const jsQR = (await import("../_libs/jsqr.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()))).default;
	const ctx = canvas.getContext("2d", { willReadFrequently: true });
	if (!ctx) return null;
	const { width, height } = canvas;
	if (width < 16 || height < 16) return null;
	return jsQR(ctx.getImageData(0, 0, width, height).data, width, height, { inversionAttempts: "attemptBoth" })?.data ?? null;
}
function makeCanvas() {
	return document.createElement("canvas");
}
function QrStage() {
	const innerRef = (0, import_react.useRef)(null);
	const workRef = (0, import_react.useRef)(null);
	const payload = useStudio((s) => s.payload);
	const style = useStudio((s) => s.style);
	const imageUrl = useStudio((s) => s.imageUrl);
	const logoUrl = useStudio((s) => s.logoUrl);
	const scanOk = useStudio((s) => s.scanOk);
	const error = useStudio((s) => s.error);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [px, setPx] = (0, import_react.useState)(420);
	const [preview, setPreview] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const el = innerRef.current;
		if (!el) return;
		const measure = () => {
			const w = el.clientWidth;
			setPx(Math.max(240, Math.min(512, Math.floor(w))));
		};
		measure();
		const ro = new ResizeObserver(measure);
		ro.observe(el);
		return () => ro.disconnect();
	}, []);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		const handle = window.setTimeout(async () => {
			const encoded = tryEncodePayload(payload, style);
			if (!encoded.ok) {
				useStudio.getState().setError(encoded.error);
				useStudio.getState().setScan(null, null);
				return;
			}
			useStudio.getState().setError(null);
			let art = null;
			let logo = null;
			if (imageUrl) art = await loadImage(imageUrl).catch(() => null);
			if (logoUrl) logo = await loadImage(logoUrl).catch(() => null);
			if (cancelled) return;
			const canvas = workRef.current ?? makeCanvas();
			workRef.current = canvas;
			renderQr(canvas, encoded.qr, style, {
				pixelSize: px,
				art,
				logo,
				exportScale: true
			});
			setPreview(canvas.toDataURL("image/png"));
			const probe = makeCanvas();
			renderQr(probe, encoded.qr, style, {
				pixelSize: 640,
				art,
				logo,
				exportScale: true
			});
			try {
				const decoded = await verifyQr(probe);
				if (!cancelled) useStudio.getState().setScan(Boolean(decoded), decoded);
			} catch {
				if (!cancelled) useStudio.getState().setScan(null, null);
			}
		}, 50);
		return () => {
			cancelled = true;
			window.clearTimeout(handle);
		};
	}, [
		payload,
		style,
		imageUrl,
		logoUrl,
		px
	]);
	async function renderExport(size) {
		const encoded = tryEncodePayload(payload, style);
		if (!encoded.ok) throw new Error(encoded.error);
		const canvas = makeCanvas();
		const art = imageUrl ? await loadImage(imageUrl).catch(() => null) : null;
		const logo = logoUrl ? await loadImage(logoUrl).catch(() => null) : null;
		renderQr(canvas, encoded.qr, style, {
			pixelSize: size,
			art,
			logo,
			exportScale: true
		});
		return canvas;
	}
	async function onDownload() {
		try {
			downloadCanvasPng(await renderExport(2048), "beacon-qr.png");
			const thumb = workRef.current?.toDataURL("image/jpeg", .6) ?? "";
			useStudio.getState().pushHistory({
				label: payloadLabel(payload),
				payload: { ...payload },
				style: { ...style },
				imageUrl: imageUrl?.startsWith("blob:") ? null : imageUrl,
				thumb
			});
			toast.success("PNG saved");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Download failed");
		}
	}
	async function onCopyImage() {
		try {
			const blob = await canvasPngBlob(await renderExport(1024));
			await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1500);
			toast.success("Copied image");
		} catch {
			toast.error("Clipboard is blocked in this browser");
		}
	}
	async function onCopyPayload() {
		const text = buildPayload(payload);
		try {
			await navigator.clipboard.writeText(text);
			toast.success("Copied destination");
		} catch {
			toast.error("Could not copy");
		}
	}
	async function onPrint() {
		try {
			const url = (await renderExport(1600)).toDataURL("image/png");
			const frame = document.createElement("iframe");
			frame.setAttribute("aria-hidden", "true");
			frame.style.position = "fixed";
			frame.style.right = "0";
			frame.style.bottom = "0";
			frame.style.width = "0";
			frame.style.height = "0";
			frame.style.border = "0";
			document.body.appendChild(frame);
			const doc = frame.contentDocument;
			if (!doc) return;
			doc.open();
			doc.write(`<html><head><title>Beacon QR</title><style>html,body{margin:0;background:#fff}img{display:block;width:80vmin;margin:8vh auto}</style></head><body><img src="${url}" /></body></html>`);
			doc.close();
			frame.onload = () => {
				frame.contentWindow?.focus();
				frame.contentWindow?.print();
				window.setTimeout(() => frame.remove(), 1e3);
			};
		} catch {
			toast.error("Print failed");
		}
	}
	function surprise() {
		const pick = PRESETS[Math.floor(Math.random() * PRESETS.length)];
		if (pick) useStudio.getState().applyPreset(pick.id);
	}
	const paper = style.bg;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col items-center justify-center gap-5 px-4 py-6 pb-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "qr-mat relative w-full max-w-[520px] rounded-2xl p-4 sm:p-7",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: innerRef,
					className: "relative mx-auto aspect-square w-full overflow-hidden rounded-xl",
					style: { background: paper },
					children: [preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: preview,
						alt: "QR code preview",
						className: "block size-full"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-full bg-surface" }), error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 flex items-center justify-center bg-bg/80 p-6 text-center text-sm text-danger",
						children: error
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none absolute left-4 top-4 sm:left-6 sm:top-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("pointer-events-auto inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium", scanOk ? "border-ok/30 bg-bg/80 text-ok" : scanOk === false ? "border-warn/30 bg-bg/80 text-warn" : "border-border bg-bg/80 text-muted"),
						children: scanOk ? "Scannable" : scanOk === false ? "Tighten contrast" : "Checking"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex w-full max-w-[520px] flex-wrap items-center justify-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: onDownload,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Download PNG"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						onClick: onCopyImage,
						children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageDown, {}), "Copy image"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						onClick: onCopyPayload,
						"aria-label": "Copy destination",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						onClick: onPrint,
						"aria-label": "Print",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						onClick: surprise,
						"aria-label": "Random preset",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, {})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-[420px] px-2 text-center text-xs text-subtle",
				children: "Phone cameras read the mark. Picture mode keeps finder eyes solid so scans stay reliable."
			})
		]
	});
}
var ScrollArea = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Root$1, {
	ref,
	className: cn("relative overflow-hidden", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Viewport, {
		className: "h-full w-full rounded-[inherit]",
		children
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scrollbar, {
		orientation: "vertical",
		className: "flex touch-none select-none p-0.5 data-[orientation=vertical]:h-full data-[orientation=vertical]:w-2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, { className: "relative flex-1 rounded-full bg-border-strong" })
	})]
}));
ScrollArea.displayName = "ScrollArea";
var TooltipProvider = Provider;
var TooltipContent = import_react.forwardRef(({ className, sideOffset = 6, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 overflow-hidden rounded-md border border-border bg-elevated px-2.5 py-1.5 text-xs text-fg shadow-md", className),
	...props
}) }));
TooltipContent.displayName = "TooltipContent";
var MOBILE_TABS = [
	{
		id: "content",
		label: "Link",
		icon: Type
	},
	{
		id: "image",
		label: "Image",
		icon: Image$1
	},
	{
		id: "presets",
		label: "Presets",
		icon: LayoutGrid
	},
	{
		id: "design",
		label: "Design",
		icon: Palette
	}
];
function Studio() {
	const mobileTab = useStudio((s) => s.mobileTab);
	const setMobileTab = useStudio((s) => s.setMobileTab);
	const hydrateHistory = useStudio((s) => s.hydrateHistory);
	(0, import_react.useEffect)(() => {
		hydrateHistory();
	}, [hydrateHistory]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, {
		delayDuration: 200,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-dvh flex-col overflow-x-hidden bg-bg text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex h-14 shrink-0 items-center justify-between border-b border-border px-4 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-2xl italic leading-none tracking-tight",
							children: "Beacon"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden text-xs text-muted sm:inline",
							children: "Picture QR studio"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs tabular-nums text-subtle",
						children: [PRESETS.length, " presets"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-[300px_minmax(0,1fr)_340px]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
							className: "hidden min-h-0 min-w-0 border-r border-border lg:flex lg:flex-col",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-b border-border px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-lg italic",
									children: "Destination"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: "What the code opens"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
								className: "min-h-0 flex-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "px-4 py-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContentPanel, {})
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
							className: "min-h-0 min-w-0 overflow-x-hidden bg-bg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrStage, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
							className: "hidden min-h-0 min-w-0 border-l border-border lg:flex lg:flex-col",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RightDesktop, {})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-t border-border lg:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-h-[42dvh] overflow-y-auto px-4 py-4 scrollbar-thin",
						children: [
							mobileTab === "content" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContentPanel, {}),
							mobileTab === "image" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePanel, {}),
							mobileTab === "presets" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresetGallery, {}),
							mobileTab === "design" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DesignPanel, {})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "grid grid-cols-4 border-t border-border",
						children: MOBILE_TABS.map((t) => {
							const Icon = t.icon;
							const on = mobileTab === t.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setMobileTab(t.id),
								className: cn("flex h-14 flex-col items-center justify-center gap-1 text-[11px] font-medium", on ? "text-fg" : "text-muted"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), t.label]
							}, t.id);
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
					theme: "dark",
					position: "bottom-center",
					richColors: false
				})
			]
		})
	});
}
function RightDesktop() {
	const tab = useStudio((s) => s.mobileTab);
	const setTab = useStudio((s) => s.setMobileTab);
	const desktopTabs = [
		{
			id: "presets",
			label: "Presets"
		},
		{
			id: "design",
			label: "Design"
		},
		{
			id: "image",
			label: "Image"
		}
	];
	const current = desktopTabs.some((t) => t.id === tab) ? tab : "presets";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-1 border-b border-border p-2",
		children: desktopTabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => setTab(t.id),
			className: cn("h-10 flex-1 rounded-md text-sm font-medium", current === t.id ? "bg-surface text-fg" : "text-muted hover:text-fg"),
			children: t.label
		}, t.id))
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
		className: "min-h-0 flex-1",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 py-4",
			children: [
				current === "presets" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresetGallery, {}),
				current === "design" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DesignPanel, {}),
				current === "image" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePanel, {})
			]
		})
	})] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, {});
}
//#endregion
export { Home as component };
